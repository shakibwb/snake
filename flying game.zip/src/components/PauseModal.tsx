/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, RotateCcw, Home } from 'lucide-react';

interface PauseModalProps {
  score: number;
  bestScore: number;
  onResume: () => void;
  onRestart: () => void;
  onHome: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  score,
  bestScore,
  onResume,
  onRestart,
  onHome,
}) => {
  return (
    <div className="absolute inset-0 z-30 bg-black/60 flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-[290px] rounded-2xl bg-slate-900/95 border-4 border-amber-400 p-5 shadow-2xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-150">
        <h2 className="font-arcade text-xl text-yellow-400 arcade-text-shadow tracking-wider mb-4">
          GAME PAUSED
        </h2>

        {/* Current Score Summary */}
        <div className="w-full bg-black/50 border border-white/10 rounded-xl p-3 mb-5 flex justify-around">
          <div>
            <span className="font-arcade text-[10px] text-slate-400 block mb-1">SCORE</span>
            <span className="font-arcade text-lg text-white tabular-nums">{score}</span>
          </div>
          <div className="w-px bg-white/10 my-1" />
          <div>
            <span className="font-arcade text-[10px] text-slate-400 block mb-1">BEST</span>
            <span className="font-arcade text-lg text-yellow-400 tabular-nums">{bestScore}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={onResume}
            className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:translate-y-0.5 border-b-4 border-emerald-700 text-white font-arcade text-xs tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg transition-transform"
          >
            <Play size={16} className="fill-white" />
            RESUME
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:translate-y-0.5 border-b-4 border-amber-700 text-white font-arcade text-xs tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg transition-transform"
          >
            <RotateCcw size={16} />
            RESTART
          </button>

          <button
            onClick={onHome}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 active:translate-y-0.5 border-b-4 border-slate-900 text-slate-200 font-arcade text-[11px] tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-transform"
          >
            <Home size={15} />
            MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
};
