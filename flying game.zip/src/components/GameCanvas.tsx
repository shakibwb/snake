/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import { GameEngine } from '../game/engine';
import { DEFAULT_CONFIG } from '../game/physics';
import { BirdSkin, GameState, MedalType, SkyTheme } from '../game/types';

interface GameCanvasProps {
  onEngineReady: (engine: GameEngine) => void;
  onStateChange: (state: GameState) => void;
  onScoreChange: (score: number) => void;
  onGameOver: (data: { score: number; bestScore: number; isNewRecord: boolean; medal: MedalType }) => void;
  currentSkin: BirdSkin;
  currentTheme: SkyTheme;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  onEngineReady,
  onStateChange,
  onScoreChange,
  onGameOver,
  currentSkin,
  currentTheme,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set fixed coordinate space
    canvas.width = DEFAULT_CONFIG.canvasWidth;
    canvas.height = DEFAULT_CONFIG.canvasHeight;

    const engine = new GameEngine(canvas);
    engineRef.current = engine;

    engine.onStateChange = onStateChange;
    engine.onScoreChange = onScoreChange;
    engine.onGameOver = onGameOver;

    engine.start();
    onEngineReady(engine);

    // Keyboard controls
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is interacting with form inputs (if any)
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        engine.flap();
      } else if (e.code === 'Escape' || e.code === 'KeyP') {
        e.preventDefault();
        if (engine.state === 'PLAYING') {
          engine.pause();
        } else if (engine.state === 'PAUSED') {
          engine.resume();
        }
      }
    };

    // Tab visibility handling
    const handleVisibilityChange = () => {
      if (document.hidden && engine.state === 'PLAYING') {
        engine.pause();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      engine.destroy();
    };
  }, []);

  // Update skin or theme changes without restarting loop
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.setSkin(currentSkin);
    }
  }, [currentSkin]);

  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.setTheme(currentTheme);
    }
  }, [currentTheme]);

  // Touch & Pointer interaction
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    // Only primary button
    if (e.button !== 0) return;
    if (engineRef.current) {
      engineRef.current.flap();
    }
  };

  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden bg-black select-none">
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        className="pixel-art block max-w-full max-h-full object-contain cursor-pointer aspect-[9/16] shadow-2xl rounded-none sm:rounded-lg"
        style={{
          width: 'auto',
          height: '100%',
          maxHeight: '100vh',
          aspectRatio: '9/16',
          touchAction: 'none',
        }}
      />
    </div>
  );
};
