/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BirdSkin, Cloud, Hill, PipePair, SkyTheme } from './types';

export class GameRenderer {
  public static drawSky(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    theme: SkyTheme,
    stars: { x: number; y: number; brightness: number; speed: number }[],
    time: number
  ) {
    if (theme === 'day') {
      const grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#4ec0ca');
      grad.addColorStop(0.7, '#83e0e8');
      grad.addColorStop(1, '#c5f2f5');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    } else if (theme === 'sunset') {
      const grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#3a1c54');
      grad.addColorStop(0.4, '#a2395a');
      grad.addColorStop(0.75, '#f37335');
      grad.addColorStop(1, '#fdc830');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Sunset sun glow
      ctx.save();
      ctx.fillStyle = 'rgba(255, 235, 150, 0.35)';
      ctx.beginPath();
      ctx.arc(width * 0.75, height * 0.52, 48, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffef96';
      ctx.beginPath();
      ctx.arc(width * 0.75, height * 0.52, 32, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    } else {
      // Night
      const grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#0b132b');
      grad.addColorStop(0.6, '#1c2541');
      grad.addColorStop(1, '#3a506b');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Draw pixel stars
      ctx.save();
      for (const star of stars) {
        const twinkle = 0.5 + 0.5 * Math.sin(time * star.speed + star.x);
        ctx.fillStyle = `rgba(255, 255, 255, ${star.brightness * twinkle})`;
        ctx.fillRect(Math.floor(star.x), Math.floor(star.y), 2, 2);
      }

      // Pixel crescent moon
      const moonX = width - 60;
      const moonY = 54;
      ctx.fillStyle = '#fdfdfd';
      ctx.beginPath();
      ctx.arc(moonX, moonY, 16, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#111a33';
      ctx.beginPath();
      ctx.arc(moonX - 7, moonY - 5, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  public static drawClouds(ctx: CanvasRenderingContext2D, clouds: Cloud[]) {
    ctx.save();
    for (const c of clouds) {
      ctx.fillStyle = `rgba(255, 255, 255, ${c.opacity})`;
      const x = Math.floor(c.x);
      const y = Math.floor(c.y);
      const w = c.width;
      const h = c.width * 0.45;

      // Draw stylized pixel-art cloud block clumps
      ctx.fillRect(x, y + h * 0.4, w, h * 0.6);
      ctx.fillRect(x + w * 0.15, y + h * 0.15, w * 0.7, h * 0.6);
      ctx.fillRect(x + w * 0.3, y, w * 0.4, h * 0.8);
      ctx.fillRect(x + w * 0.5, y + h * 0.2, w * 0.35, h * 0.6);
    }
    ctx.restore();
  }

  public static drawDistantHills(
    ctx: CanvasRenderingContext2D,
    hills: Hill[],
    groundY: number,
    theme: SkyTheme
  ) {
    ctx.save();
    const hillColor =
      theme === 'day'
        ? '#6bc272'
        : theme === 'sunset'
        ? '#4a2545'
        : '#192b45';
    const darkHillColor =
      theme === 'day'
        ? '#57ab5e'
        : theme === 'sunset'
        ? '#321630'
        : '#121f33';

    // Back layer
    ctx.fillStyle = darkHillColor;
    for (const h of hills) {
      ctx.beginPath();
      ctx.arc(h.x, groundY + 20, h.radius * 1.15, Math.PI, 0, false);
      ctx.fill();
    }

    // Front layer
    ctx.fillStyle = hillColor;
    for (const h of hills) {
      ctx.beginPath();
      ctx.arc(h.x + 40, groundY + 30, h.radius, Math.PI, 0, false);
      ctx.fill();
    }
    ctx.restore();
  }

  public static drawGround(
    ctx: CanvasRenderingContext2D,
    width: number,
    groundY: number,
    groundHeight: number,
    scrollOffset: number
  ) {
    ctx.save();

    // 1. Top green grass rim
    ctx.fillStyle = '#73bf2e';
    ctx.fillRect(0, groundY, width, 14);

    // Dark outline top
    ctx.fillStyle = '#3a5f18';
    ctx.fillRect(0, groundY, width, 2);

    // Lighter highlight line on grass
    ctx.fillStyle = '#9ce659';
    ctx.fillRect(0, groundY + 2, width, 3);

    // Little grass blades / pixel tufts
    ctx.fillStyle = '#558c22';
    const tuftSpacing = 16;
    const tuftOffset = Math.floor(scrollOffset % tuftSpacing);
    for (let x = -tuftSpacing; x < width + tuftSpacing; x += tuftSpacing) {
      ctx.fillRect(x - tuftOffset, groundY + 11, 6, 3);
    }

    // 2. Dirt base
    ctx.fillStyle = '#ded895';
    ctx.fillRect(0, groundY + 14, width, groundHeight - 14);

    // Dirt divider line
    ctx.fillStyle = '#bfa55a';
    ctx.fillRect(0, groundY + 14, width, 2);

    // 3. Diagonal scrolling stripe texture
    const stripeWidth = 14;
    const stripeOffset = Math.floor(scrollOffset % (stripeWidth * 2));
    ctx.fillStyle = '#c8bc73';

    for (let x = -stripeWidth * 2; x < width + stripeWidth * 2; x += stripeWidth * 2) {
      const px = x - stripeOffset;
      ctx.beginPath();
      ctx.moveTo(px, groundY + 16);
      ctx.lineTo(px + stripeWidth, groundY + 16);
      ctx.lineTo(px - 10 + stripeWidth, groundY + groundHeight);
      ctx.lineTo(px - 10, groundY + groundHeight);
      ctx.closePath();
      ctx.fill();
    }

    // Little dark pixel stones scattered in dirt
    ctx.fillStyle = '#9c833d';
    const stoneDist = 36;
    const stoneOffset = Math.floor(scrollOffset % stoneDist);
    for (let x = -stoneDist; x < width + stoneDist; x += stoneDist) {
      const sx = x - stoneOffset;
      ctx.fillRect(sx + 5, groundY + 30, 4, 3);
      ctx.fillRect(sx + 18, groundY + 54, 5, 4);
      ctx.fillRect(sx + 26, groundY + 40, 3, 3);
    }

    ctx.restore();
  }

  public static drawPipePair(ctx: CanvasRenderingContext2D, pipe: PipePair, canvasHeight: number) {
    const { x, topHeight, bottomY, width } = pipe;
    const capHeight = 24;
    const capOverhang = 3;

    // Draw Top Pipe
    this.drawSinglePipe(
      ctx,
      x,
      0,
      width,
      topHeight,
      capHeight,
      capOverhang,
      'top'
    );

    // Draw Bottom Pipe
    const bottomPipeHeight = canvasHeight - bottomY;
    this.drawSinglePipe(
      ctx,
      x,
      bottomY,
      width,
      bottomPipeHeight,
      capHeight,
      capOverhang,
      'bottom'
    );
  }

  private static drawSinglePipe(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    capHeight: number,
    capOverhang: number,
    type: 'top' | 'bottom'
  ) {
    ctx.save();

    // Body rectangle
    const bodyX = x;
    const bodyY = type === 'top' ? y : y + capHeight;
    const bodyH = Math.max(0, type === 'top' ? height - capHeight : height - capHeight);

    // Pipe Cap
    const capX = x - capOverhang;
    const capY = type === 'top' ? height - capHeight : y;
    const capW = width + capOverhang * 2;

    // 1. Draw Body
    if (bodyH > 0) {
      // Main green body
      ctx.fillStyle = '#73bf2e';
      ctx.fillRect(bodyX, bodyY, width, bodyH);

      // Dark outer border
      ctx.fillStyle = '#2c5e1a';
      ctx.fillRect(bodyX, bodyY, 2, bodyH); // left border
      ctx.fillRect(bodyX + width - 2, bodyY, 2, bodyH); // right border

      // Left Highlight stripe
      ctx.fillStyle = '#9ce659';
      ctx.fillRect(bodyX + 3, bodyY, 6, bodyH);

      // Light center sheen
      ctx.fillStyle = '#83d336';
      ctx.fillRect(bodyX + 9, bodyY, 4, bodyH);

      // Right Shadow stripe
      ctx.fillStyle = '#558c22';
      ctx.fillRect(bodyX + width - 10, bodyY, 8, bodyH);
      ctx.fillStyle = '#3a6616';
      ctx.fillRect(bodyX + width - 4, bodyY, 2, bodyH);
    }

    // 2. Draw Cap
    // Cap main
    ctx.fillStyle = '#73bf2e';
    ctx.fillRect(capX, capY, capW, capHeight);

    // Cap dark border
    ctx.strokeStyle = '#2c5e1a';
    ctx.lineWidth = 2;
    ctx.strokeRect(capX + 1, capY + 1, capW - 2, capHeight - 2);

    // Cap highlights and shadows
    ctx.fillStyle = '#9ce659';
    ctx.fillRect(capX + 3, capY + 2, 7, capHeight - 4);

    ctx.fillStyle = '#83d336';
    ctx.fillRect(capX + 10, capY + 2, 4, capHeight - 4);

    ctx.fillStyle = '#558c22';
    ctx.fillRect(capX + capW - 12, capY + 2, 9, capHeight - 4);

    ctx.fillStyle = '#3a6616';
    ctx.fillRect(capX + capW - 4, capY + 2, 2, capHeight - 4);

    // Cap horizontal rim highlight & shadow
    if (type === 'top') {
      // Bottom rim faces the gap
      ctx.fillStyle = '#224813';
      ctx.fillRect(capX + 2, capY + capHeight - 3, capW - 4, 2);
      ctx.fillStyle = '#ffffff';
      ctx.globalAlpha = 0.35;
      ctx.fillRect(capX + 2, capY + 2, capW - 4, 2);
    } else {
      // Top rim faces the gap
      ctx.fillStyle = '#ffffff';
      ctx.globalAlpha = 0.4;
      ctx.fillRect(capX + 2, capY + 2, capW - 4, 2);
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#224813';
      ctx.fillRect(capX + 2, capY + capHeight - 3, capW - 4, 2);
    }

    ctx.restore();
  }

  public static drawBird(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    rotation: number,
    skin: BirdSkin,
    wingFrame: number // 0: up, 1: mid, 2: down
  ) {
    ctx.save();
    ctx.translate(Math.floor(x), Math.floor(y));
    ctx.rotate(rotation);

    const outlineColor = '#1c1b18';

    // 1. Little tail feathers behind body
    ctx.fillStyle = outlineColor;
    ctx.fillRect(-17, -3, 6, 7);
    ctx.fillStyle = skin.bodyShadow;
    ctx.fillRect(-16, -2, 4, 5);

    // 2. Plump round body (Pixel art layered ellipse)
    // Dark outline
    ctx.fillStyle = outlineColor;
    ctx.beginPath();
    ctx.ellipse(0, 0, 15, 12, 0, 0, Math.PI * 2);
    ctx.fill();

    // Body base color
    ctx.fillStyle = skin.bodyColor;
    ctx.beginPath();
    ctx.ellipse(0, 0, 13, 10, 0, 0, Math.PI * 2);
    ctx.fill();

    // Body top highlight
    ctx.fillStyle = skin.bodyHighlight;
    ctx.beginPath();
    ctx.ellipse(-1, -4, 10, 5, -0.1, 0, Math.PI * 2);
    ctx.fill();

    // Body bottom shadow
    ctx.fillStyle = skin.bodyShadow;
    ctx.beginPath();
    ctx.ellipse(0, 5, 9, 4, 0, 0, Math.PI);
    ctx.fill();

    // White belly
    ctx.fillStyle = skin.bellyColor;
    ctx.beginPath();
    ctx.ellipse(-3, 3, 7, 5, 0.2, 0, Math.PI * 2);
    ctx.fill();

    // 3. Eye
    const eyeX = 6;
    const eyeY = -4;

    // Eye white with outline
    ctx.fillStyle = outlineColor;
    ctx.beginPath();
    ctx.arc(eyeX, eyeY, 5.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(eyeX, eyeY, 4.5, 0, Math.PI * 2);
    ctx.fill();

    // Pupil
    ctx.fillStyle = outlineColor;
    ctx.beginPath();
    ctx.arc(eyeX + 1.5, eyeY, 2.2, 0, Math.PI * 2);
    ctx.fill();

    // Eye catchlight glint
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(eyeX + 1, eyeY - 2, 1.8, 1.8);

    // 4. Beak
    const beakX = 11;
    const beakY = 0;

    // Beak outline
    ctx.fillStyle = outlineColor;
    ctx.beginPath();
    ctx.moveTo(beakX, beakY - 3);
    ctx.lineTo(beakX + 10, beakY + 1);
    ctx.lineTo(beakX, beakY + 6);
    ctx.closePath();
    ctx.fill();

    // Beak top
    ctx.fillStyle = skin.beakColor;
    ctx.beginPath();
    ctx.moveTo(beakX + 1, beakY - 2);
    ctx.lineTo(beakX + 8, beakY + 1);
    ctx.lineTo(beakX + 1, beakY + 2);
    ctx.closePath();
    ctx.fill();

    // Beak bottom & shadow
    ctx.fillStyle = skin.beakShadow;
    ctx.beginPath();
    ctx.moveTo(beakX + 1, beakY + 2);
    ctx.lineTo(beakX + 8, beakY + 1);
    ctx.lineTo(beakX + 1, beakY + 5);
    ctx.closePath();
    ctx.fill();

    // Mouth line
    ctx.fillStyle = outlineColor;
    ctx.fillRect(beakX + 1, beakY + 1, 6, 1);

    // 5. Wing (Animated according to wingFrame)
    ctx.save();
    let wingOffsetY = 0;
    let wingAngle = 0;

    if (wingFrame === 0) {
      // Up
      wingOffsetY = -6;
      wingAngle = -0.45;
    } else if (wingFrame === 1) {
      // Mid
      wingOffsetY = 0;
      wingAngle = 0;
    } else {
      // Down
      wingOffsetY = 5;
      wingAngle = 0.55;
    }

    ctx.translate(-4, wingOffsetY);
    ctx.rotate(wingAngle);

    // Wing outline
    ctx.fillStyle = outlineColor;
    ctx.beginPath();
    ctx.ellipse(0, 0, 7.5, 5, -0.2, 0, Math.PI * 2);
    ctx.fill();

    // Wing base
    ctx.fillStyle = skin.wingColor;
    ctx.beginPath();
    ctx.ellipse(0, 0, 6, 3.8, -0.2, 0, Math.PI * 2);
    ctx.fill();

    // Wing shadow/feather stripe
    ctx.fillStyle = skin.wingShadow;
    ctx.beginPath();
    ctx.ellipse(0, 1.5, 4.5, 2, -0.2, 0, Math.PI);
    ctx.fill();

    ctx.restore();

    ctx.restore();
  }

  public static drawScore(ctx: CanvasRenderingContext2D, score: number, width: number, y: number = 72) {
    const text = score.toString();
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '32px "Press Start 2P", monospace';

    // Bold pixel drop shadow
    ctx.fillStyle = '#000000';
    for (let dx = -3; dx <= 3; dx++) {
      for (let dy = -3; dy <= 3; dy++) {
        if (dx !== 0 || dy !== 0) {
          ctx.fillText(text, width / 2 + dx, y + dy);
        }
      }
    }

    // Center white text
    ctx.fillStyle = '#ffffff';
    ctx.fillText(text, width / 2, y);

    ctx.restore();
  }

  public static drawMedal(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    tier: 'bronze' | 'silver' | 'gold' | 'platinum',
    time: number = 0
  ) {
    ctx.save();
    ctx.translate(x, y);

    // Color definitions
    const palettes = {
      bronze: {
        rim: '#78461b',
        body: '#b56d35',
        hi: '#df9253',
        shade: '#573010',
        ribbon: '#d90429',
      },
      silver: {
        rim: '#52616b',
        body: '#a3b1c6',
        hi: '#e9ecef',
        shade: '#394852',
        ribbon: '#1d3557',
      },
      gold: {
        rim: '#a67c00',
        body: '#ffd700',
        hi: '#fff59d',
        shade: '#755400',
        ribbon: '#0077b6',
      },
      platinum: {
        rim: '#3a0ca3',
        body: '#00f0ff',
        hi: '#ffffff',
        shade: '#03045e',
        ribbon: '#7209b7',
      },
    };

    const p = palettes[tier];

    // Ribbon
    ctx.fillStyle = p.ribbon;
    ctx.beginPath();
    ctx.moveTo(-10, -18);
    ctx.lineTo(10, -18);
    ctx.lineTo(8, -4);
    ctx.lineTo(-8, -4);
    ctx.closePath();
    ctx.fill();

    // Medal rim outer
    ctx.fillStyle = p.rim;
    ctx.beginPath();
    ctx.arc(0, 0, 18, 0, Math.PI * 2);
    ctx.fill();

    // Medal main body
    ctx.fillStyle = p.body;
    ctx.beginPath();
    ctx.arc(0, 0, 15, 0, Math.PI * 2);
    ctx.fill();

    // Highlight crescent
    ctx.fillStyle = p.hi;
    ctx.beginPath();
    ctx.arc(-2, -2, 11, -Math.PI * 0.7, Math.PI * 0.3);
    ctx.lineTo(0, 0);
    ctx.closePath();
    ctx.fill();

    // Inner bevel
    ctx.fillStyle = p.shade;
    ctx.beginPath();
    ctx.arc(0, 0, 9, 0, Math.PI * 2);
    ctx.fill();

    // Central star
    ctx.fillStyle = p.hi;
    ctx.fillRect(-2, -6, 4, 12);
    ctx.fillRect(-6, -2, 12, 4);

    // Shimmer sparkle
    const shimmer = (Math.sin(time * 3) + 1) * 0.5;
    ctx.fillStyle = `rgba(255, 255, 255, ${shimmer * 0.8})`;
    ctx.fillRect(-8, -8, 4, 4);

    ctx.restore();
  }
}
