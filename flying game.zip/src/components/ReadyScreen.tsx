/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BIRD_SKINS } from '../game/storage';
import { BirdSkin, BirdSkinId } from '../game/types';
import { Lock, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';

interface ReadyScreenProps {
  currentSkin: BirdSkin;
  unlockedSkins: BirdSkinId[];
  highScore: number;
  onSelectSkin: (skin: BirdSkin) => void;
  onStartGame: () => void;
}

export const ReadyScreen: React.FC<ReadyScreenProps> = ({
  currentSkin,
  unlockedSkins,
  highScore,
  onSelectSkin,
  onStartGame,
}) => {
  const allSkins = Object.values(BIRD_SKINS);
  const currentIndex = allSkins.findIndex((s) => s.id === currentSkin.id);

  const prevSkin = () => {
    const newIdx = (currentIndex - 1 + allSkins.length) % allSkins.length;
    onSelectSkin(allSkins[newIdx]);
  };

  const nextSkin = () => {
    const newIdx = (currentIndex + 1) % allSkins.length;
    onSelectSkin(allSkins[newIdx]);
  };

  const isUnlocked = unlockedSkins.includes(currentSkin.id);

  return (
    <div className="absolute inset-0 z-10 flex flex-col justify-between p-5 pointer-events-none select-none">
      {/* Top Title Lockup */}
      <div className="mt-14 flex flex-col items-center pointer-events-auto">
        <div className="relative text-center">
          <h1 className="font-arcade text-3xl sm:text-4xl tracking-wider text-yellow-300 arcade-text-shadow leading-tight">
            PIXEL<br />FLIGHT
          </h1>
          <p className="font-arcade text-[10px] text-emerald-200 mt-2 arcade-text-shadow tracking-widest">
            CLASSIC ARCADE
          </p>
        </div>
      </div>

      {/* Middle Tap Guide */}
      <div className="flex flex-col items-center my-auto pointer-events-auto">
        <button
          onClick={onStartGame}
          className="group relative cursor-pointer flex flex-col items-center active:scale-95 transition-transform"
        >
          {/* Animated pulsing tap hint */}
          <div className="px-5 py-3 rounded-xl bg-black/60 border-2 border-yellow-400/80 shadow-lg text-center backdrop-blur-[2px] animate-bounce">
            <span className="font-arcade text-xs text-yellow-300 block tracking-wide">
              GET READY!
            </span>
            <span className="text-[11px] text-white/90 font-medium block mt-1 tracking-tight">
              Tap screen or press <span className="underline decoration-yellow-400">Space</span>
            </span>
          </div>
        </button>
      </div>

      {/* Bottom Aviary / Skin Selector & Best Score */}
      <div className="mb-2 flex flex-col items-center gap-3 pointer-events-auto">
        {/* Skin Selector */}
        <div className="w-full max-w-[320px] px-3 py-2.5 rounded-xl bg-black/70 border-2 border-white/20 shadow-xl flex items-center justify-between">
          <button
            onClick={prevSkin}
            aria-label="Previous bird skin"
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 active:translate-y-0.5 text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <ChevronLeft size={18} />
          </button>

          <div className="flex flex-col items-center text-center px-2">
            <div className="flex items-center gap-1.5">
              {/* Color swatch dot */}
              <span
                className="w-3 h-3 rounded-full border border-black/40 inline-block"
                style={{ backgroundColor: currentSkin.bodyColor }}
              />
              <span className="font-arcade text-[11px] text-white tracking-wide truncate max-w-[170px]">
                {currentSkin.name}
              </span>
              {!isUnlocked && <Lock size={12} className="text-amber-400 shrink-0" />}
            </div>

            <div className="text-[10px] text-slate-300 mt-0.5">
              {isUnlocked ? (
                <span className="text-emerald-400 flex items-center gap-1">
                  <Sparkles size={10} /> Active Skin
                </span>
              ) : (
                <span className="text-amber-300">
                  Unlocks at Score {currentSkin.unlockScore}
                </span>
              )}
            </div>
          </div>

          <button
            onClick={nextSkin}
            aria-label="Next bird skin"
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 active:translate-y-0.5 text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <ChevronRight size={18} />
          </button>
        </div>

        {/* Best Score Indicator */}
        <div className="text-[10px] font-arcade text-white/80 arcade-text-shadow">
          HIGH SCORE: <span className="text-yellow-400 tabular-nums">{highScore}</span>
        </div>
      </div>
    </div>
  );
};
