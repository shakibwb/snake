/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { RotateCcw, Home, BarChart2, Share2, Check } from 'lucide-react';
import { MedalType } from '../game/types';

interface GameOverModalProps {
  score: number;
  bestScore: number;
  isNewRecord: boolean;
  medal: MedalType;
  onRestart: () => void;
  onHome: () => void;
  onOpenStats: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  bestScore,
  isNewRecord,
  medal,
  onRestart,
  onHome,
  onOpenStats,
}) => {
  const [copied, setCopied] = useState(false);
  const [displayScore, setDisplayScore] = useState(0);

  // Score rolling animation
  useEffect(() => {
    let start = 0;
    const duration = Math.min(800, score * 30 + 100);
    const startTime = performance.now();

    const animate = (time: number) => {
      const elapsed = time - startTime;
      const progress = Math.min(1, elapsed / duration);
      setDisplayScore(Math.floor(progress * score));
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    const id = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(id);
  }, [score]);

  const handleShare = async () => {
    const text = `🎮 I just scored ${score} in Flappy Arcade: Pixel Flight! Can you beat my best of ${bestScore}?`;
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="absolute inset-0 z-30 bg-black/55 flex flex-col items-center justify-center p-4 select-none">
      <div className="w-full max-w-[320px] flex flex-col items-center animate-in fade-in zoom-in-95 duration-200">
        {/* Title */}
        <h2 className="font-arcade text-2xl sm:text-3xl text-red-500 arcade-text-shadow tracking-widest mb-3 text-center animate-pulse">
          GAME OVER
        </h2>

        {/* Arcade Score Board */}
        <div className="w-full rounded-2xl bg-gradient-to-b from-[#e8dcb5] to-[#c7b282] border-4 border-[#593d18] shadow-2xl p-4 text-[#3d260c] relative mb-4">
          {/* Decorative Corner Screws */}
          <span className="absolute top-1.5 left-1.5 w-2 h-2 rounded-full bg-[#593d18]" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#593d18]" />
          <span className="absolute bottom-1.5 left-1.5 w-2 h-2 rounded-full bg-[#593d18]" />
          <span className="absolute bottom-1.5 right-1.5 w-2 h-2 rounded-full bg-[#593d18]" />

          <div className="flex items-center justify-between gap-3">
            {/* Medal Slot */}
            <div className="flex flex-col items-center">
              <span className="font-arcade text-[9px] text-[#704d1f] tracking-wider mb-1.5">
                MEDAL
              </span>
              <div className="w-16 h-16 rounded-xl bg-[#9c845b] border-2 border-[#593d18] shadow-inner flex flex-col items-center justify-center relative overflow-hidden">
                {medal ? (
                  <div className="flex flex-col items-center animate-bounce">
                    {/* Pixel Medal Graphic */}
                    <div
                      className={`w-9 h-9 rounded-full border-2 border-[#3d260c] flex items-center justify-center shadow-md ${
                        medal === 'platinum'
                          ? 'bg-gradient-to-tr from-cyan-400 via-sky-200 to-white'
                          : medal === 'gold'
                          ? 'bg-gradient-to-tr from-amber-500 via-yellow-300 to-yellow-100'
                          : medal === 'silver'
                          ? 'bg-gradient-to-tr from-slate-400 via-slate-200 to-white'
                          : 'bg-gradient-to-tr from-amber-700 via-amber-600 to-orange-300'
                      }`}
                    >
                      <span className="font-arcade text-[10px] text-black/80 font-bold">★</span>
                    </div>
                    <span className="font-arcade text-[7px] text-[#3d260c] uppercase font-bold mt-1">
                      {medal}
                    </span>
                  </div>
                ) : (
                  <span className="font-arcade text-[10px] text-white/50 tracking-tighter">
                    NONE
                  </span>
                )}
              </div>
              <span className="text-[9px] text-[#593d18] mt-1 font-medium">
                {medal ? `${medal.toUpperCase()} EARNED!` : 'Score 10+ for Medal'}
              </span>
            </div>

            {/* Score Numbers Cluster */}
            <div className="flex-1 flex flex-col gap-2 pl-3 border-l-2 border-[#8a6e42]">
              {/* Score */}
              <div className="flex flex-col items-end">
                <span className="font-arcade text-[9px] text-[#704d1f] tracking-wider">
                  SCORE
                </span>
                <span className="font-arcade text-xl sm:text-2xl text-[#2b1704] tabular-nums">
                  {displayScore}
                </span>
              </div>

              {/* Best */}
              <div className="flex flex-col items-end relative">
                {isNewRecord && (
                  <span className="absolute -top-3.5 right-0 bg-red-600 border border-white text-white font-arcade text-[7px] px-1.5 py-0.5 rounded shadow animate-bounce">
                    NEW!
                  </span>
                )}
                <span className="font-arcade text-[9px] text-[#704d1f] tracking-wider">
                  BEST
                </span>
                <span className="font-arcade text-xl sm:text-2xl text-[#c45308] tabular-nums">
                  {bestScore}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Primary CTA Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={onRestart}
            className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:translate-y-0.5 border-b-4 border-emerald-700 text-white font-arcade text-xs tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg transition-transform"
          >
            <RotateCcw size={16} />
            PLAY AGAIN
          </button>

          <div className="w-full grid grid-cols-3 gap-2">
            <button
              onClick={onHome}
              title="Main Menu"
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:translate-y-0.5 border-b-4 border-slate-950 text-slate-200 font-arcade text-[10px] flex items-center justify-center gap-1 cursor-pointer transition-transform"
            >
              <Home size={14} />
              MENU
            </button>

            <button
              onClick={onOpenStats}
              title="Stats"
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:translate-y-0.5 border-b-4 border-slate-950 text-slate-200 font-arcade text-[10px] flex items-center justify-center gap-1 cursor-pointer transition-transform"
            >
              <BarChart2 size={14} />
              STATS
            </button>

            <button
              onClick={handleShare}
              title="Share Score"
              className="py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 active:translate-y-0.5 border-b-4 border-amber-800 text-white font-arcade text-[10px] flex items-center justify-center gap-1 cursor-pointer transition-transform"
            >
              {copied ? <Check size={14} className="text-emerald-300" /> : <Share2 size={14} />}
              {copied ? 'COPIED!' : 'SHARE'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
