/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GamePhysicsConfig, PipePair } from './types';

export const DEFAULT_CONFIG: GamePhysicsConfig = {
  gravity: 1350, // px/s^2
  flapStrength: -410, // px/s
  maxFallSpeed: 560, // px/s
  pipeSpeed: 155, // px/s
  pipeSpawnDistance: 190, // px between pipes
  initialPipeGap: 146, // px gap
  minPipeGap: 122, // min px gap
  canvasWidth: 360,
  canvasHeight: 640,
  groundHeight: 112,
};

export class PhysicsEngine {
  public static getDifficulty(score: number): { speed: number; gap: number } {
    // Smooth difficulty ramp
    const speed = Math.min(210, DEFAULT_CONFIG.pipeSpeed + score * 1.4);
    const gap = Math.max(DEFAULT_CONFIG.minPipeGap, DEFAULT_CONFIG.initialPipeGap - score * 0.65);
    return { speed, gap };
  }

  public static checkCollision(
    birdX: number,
    birdY: number,
    pipes: PipePair[],
    groundY: number
  ): boolean {
    const birdRadius = 10; // Tight, fair circular hitbox centered on bird

    // 1. Ground collision
    if (birdY + birdRadius >= groundY) {
      return true;
    }

    // 2. Ceiling collision (can't fly above top of screen)
    if (birdY - birdRadius <= 2) {
      return true;
    }

    // 3. Pipe collisions
    const capHeight = 24;
    const capOverhang = 3;

    for (const pipe of pipes) {
      // Fast AABB pre-check: Is bird horizontally near the pipe?
      const pipeLeft = pipe.x - capOverhang;
      const pipeRight = pipe.x + pipe.width + capOverhang;

      if (birdX + birdRadius < pipeLeft || birdX - birdRadius > pipeRight) {
        continue;
      }

      // Check Top Pipe Cap & Body
      // Top pipe occupies [0, pipe.topHeight]
      // Cap is at [pipe.topHeight - capHeight, pipe.topHeight] with width pipe.width + capOverhang * 2
      // Body is at [0, pipe.topHeight - capHeight] with width pipe.width
      if (birdY - birdRadius < pipe.topHeight) {
        // Detailed check against top cap
        if (birdY - birdRadius < pipe.topHeight) {
          const capTop = pipe.topHeight - capHeight;
          if (this.circleIntersectsRect(birdX, birdY, birdRadius, pipeLeft, capTop, pipe.width + capOverhang * 2, capHeight)) {
            return true;
          }
        }
        // Detailed check against top body
        if (this.circleIntersectsRect(birdX, birdY, birdRadius, pipe.x, 0, pipe.width, pipe.topHeight - capHeight)) {
          return true;
        }
      }

      // Check Bottom Pipe Cap & Body
      // Bottom pipe starts at pipe.bottomY
      // Cap is at [pipe.bottomY, pipe.bottomY + capHeight]
      if (birdY + birdRadius > pipe.bottomY) {
        // Cap
        if (this.circleIntersectsRect(birdX, birdY, birdRadius, pipeLeft, pipe.bottomY, pipe.width + capOverhang * 2, capHeight)) {
          return true;
        }
        // Body
        if (this.circleIntersectsRect(birdX, birdY, birdRadius, pipe.x, pipe.bottomY + capHeight, pipe.width, 800)) {
          return true;
        }
      }
    }

    return false;
  }

  private static circleIntersectsRect(
    cx: number,
    cy: number,
    radius: number,
    rx: number,
    ry: number,
    rw: number,
    rh: number
  ): boolean {
    const closestX = Math.max(rx, Math.min(cx, rx + rw));
    const closestY = Math.max(ry, Math.min(cy, ry + rh));

    const distanceX = cx - closestX;
    const distanceY = cy - closestY;

    return distanceX * distanceX + distanceY * distanceY < radius * radius;
  }
}
