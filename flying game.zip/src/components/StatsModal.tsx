/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Trophy, Check, Lock } from 'lucide-react';
import { BIRD_SKINS } from '../game/storage';
import { BirdSkin, BirdSkinId, GameStats } from '../game/types';

interface StatsModalProps {
  stats: GameStats;
  currentSkin: BirdSkin;
  onSelectSkin: (skin: BirdSkin) => void;
  onClose: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({
  stats,
  currentSkin,
  onSelectSkin,
  onClose,
}) => {
  const medals = [
    { type: 'bronze', name: 'Bronze Pilot', req: 10, color: 'from-amber-700 to-orange-400' },
    { type: 'silver', name: 'Silver Ace', req: 20, color: 'from-slate-400 to-slate-100' },
    { type: 'gold', name: 'Gold Champion', req: 30, color: 'from-amber-500 to-yellow-200' },
    { type: 'platinum', name: 'Platinum Legend', req: 40, color: 'from-cyan-400 to-indigo-200' },
  ];

  return (
    <div className="absolute inset-0 z-40 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-[340px] max-h-[90vh] overflow-y-auto rounded-2xl bg-slate-900 border-2 border-white/20 p-5 shadow-2xl flex flex-col text-white text-left animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2">
            <Trophy size={18} className="text-yellow-400" />
            <h3 className="font-arcade text-xs text-yellow-300 tracking-wider">
              ARCADE RECORDS
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 active:translate-y-0.5 text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-2.5 mb-5">
          <div className="bg-black/50 border border-white/10 rounded-xl p-3">
            <span className="text-[10px] text-slate-400 block mb-0.5">HIGH SCORE</span>
            <span className="font-arcade text-lg text-yellow-400 tabular-nums">
              {stats.highScore}
            </span>
          </div>
          <div className="bg-black/50 border border-white/10 rounded-xl p-3">
            <span className="text-[10px] text-slate-400 block mb-0.5">GAMES PLAYED</span>
            <span className="font-arcade text-lg text-white tabular-nums">
              {stats.gamesPlayed}
            </span>
          </div>
          <div className="bg-black/50 border border-white/10 rounded-xl p-3">
            <span className="text-[10px] text-slate-400 block mb-0.5">PIPES CLEARED</span>
            <span className="font-arcade text-lg text-emerald-400 tabular-nums">
              {stats.totalPipesPassed}
            </span>
          </div>
          <div className="bg-black/50 border border-white/10 rounded-xl p-3">
            <span className="text-[10px] text-slate-400 block mb-0.5">TOTAL FLAPS</span>
            <span className="font-arcade text-lg text-cyan-400 tabular-nums">
              {stats.totalFlaps}
            </span>
          </div>
        </div>

        {/* Medal Cabinet */}
        <div className="mb-5">
          <h4 className="font-arcade text-[10px] text-slate-300 tracking-wider mb-2.5">
            MEDAL CABINET
          </h4>
          <div className="grid grid-cols-4 gap-2">
            {medals.map((m) => {
              const isEarned = stats.highScore >= m.req;
              return (
                <div
                  key={m.type}
                  className={`rounded-xl border p-2 flex flex-col items-center text-center transition-all ${
                    isEarned
                      ? 'bg-white/5 border-amber-400/50'
                      : 'bg-black/40 border-white/5 opacity-50'
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-full border border-black/50 flex items-center justify-center mb-1 bg-gradient-to-tr ${
                      m.color
                    } ${!isEarned && 'grayscale'}`}
                  >
                    <span className="text-black font-bold text-xs">★</span>
                  </div>
                  <span className="text-[8px] font-arcade leading-tight truncate w-full text-white/90">
                    {m.req}+
                  </span>
                  <span className="text-[8px] text-slate-400 mt-0.5">
                    {isEarned ? 'UNLOCKED' : 'LOCKED'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bird Skins Unlocker */}
        <div className="mb-4">
          <h4 className="font-arcade text-[10px] text-slate-300 tracking-wider mb-2.5">
            AVIARY SKINS
          </h4>
          <div className="flex flex-col gap-2">
            {Object.values(BIRD_SKINS).map((skin) => {
              const isUnlocked = stats.unlockedSkins.includes(skin.id);
              const isEquipped = currentSkin.id === skin.id;

              return (
                <div
                  key={skin.id}
                  className={`px-3 py-2 rounded-xl border flex items-center justify-between transition-colors ${
                    isEquipped
                      ? 'bg-yellow-500/20 border-yellow-400'
                      : 'bg-black/40 border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-4 h-4 rounded-full border border-black/40 shrink-0"
                      style={{ backgroundColor: skin.bodyColor }}
                    />
                    <div>
                      <div className="font-arcade text-[10px] text-white">
                        {skin.name}
                      </div>
                      <div className="text-[9px] text-slate-400">
                        {isUnlocked
                          ? isEquipped
                            ? 'Equipped'
                            : 'Unlocked'
                          : `Reach score ${skin.unlockScore}`}
                      </div>
                    </div>
                  </div>

                  {isUnlocked ? (
                    <button
                      onClick={() => onSelectSkin(skin)}
                      disabled={isEquipped}
                      className={`px-2.5 py-1 rounded-lg text-[9px] font-arcade tracking-wide transition-colors ${
                        isEquipped
                          ? 'bg-yellow-400 text-black cursor-default'
                          : 'bg-white/10 hover:bg-white/20 text-white cursor-pointer'
                      }`}
                    >
                      {isEquipped ? 'ACTIVE' : 'EQUIP'}
                    </button>
                  ) : (
                    <Lock size={14} className="text-slate-500 mr-2" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:translate-y-0.5 border-b-4 border-slate-950 text-white font-arcade text-[10px] cursor-pointer mt-auto transition-transform"
        >
          BACK TO GAME
        </button>
      </div>
    </div>
  );
};
