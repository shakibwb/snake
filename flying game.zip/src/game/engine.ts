/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { soundManager } from './audio';
import { ParticleSystem } from './particles';
import { DEFAULT_CONFIG, PhysicsEngine } from './physics';
import { GameRenderer } from './renderer';
import { BIRD_SKINS, StorageManager } from './storage';
import { BirdSkin, Cloud, GameState, Hill, MedalType, PipePair, SkyTheme } from './types';

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;

  public state: GameState = 'READY';
  public score: number = 0;
  public bestScore: number = 0;
  public isNewRecord: boolean = false;
  public currentMedal: MedalType = null;

  // Bird state
  public birdX: number = 90;
  public birdY: number = 260;
  public birdVy: number = 0;
  public birdRotation: number = 0;
  public wingFrame: number = 0;
  private wingTimer: number = 0;

  // Environment & Scenery
  public groundY: number = 528; // 640 - 112
  public groundScroll: number = 0;
  private clouds: Cloud[] = [];
  private hills: Hill[] = [];
  private stars: { x: number; y: number; brightness: number; speed: number }[] = [];

  // Pipes
  public pipes: PipePair[] = [];
  private nextPipeId: number = 1;
  private lastPipeSpawnX: number = 0;

  // Particles & Game Feel Juice
  public particles: ParticleSystem = new ParticleSystem();
  private screenShake: number = 0;
  private hitFlash: number = 0;
  private hitstopTimer: number = 0;
  private birdDeadOnGround: boolean = false;

  // Stats in current run
  private flapsInCurrentGame: number = 0;
  private pipesPassedInCurrentGame: number = 0;

  // Settings
  public currentSkin: BirdSkin = BIRD_SKINS.classic;
  public currentTheme: SkyTheme = 'day';

  // Animation Loop
  private lastTime: number = 0;
  private animFrameId: number | null = null;
  private isDestroyed: boolean = false;

  // Callbacks to UI
  public onStateChange?: (state: GameState) => void;
  public onScoreChange?: (score: number) => void;
  public onGameOver?: (data: { score: number; bestScore: number; isNewRecord: boolean; medal: MedalType }) => void;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false })!;
    this.initEnvironment();
    this.loadSavedSettings();
    this.resetReadyState();
  }

  private loadSavedSettings() {
    const stats = StorageManager.getStats();
    this.bestScore = stats.highScore;
    this.currentSkin = BIRD_SKINS[stats.selectedSkin] || BIRD_SKINS.classic;
    this.currentTheme = stats.selectedTheme || 'day';
    soundManager.setMuted(!stats.soundEnabled);
  }

  private initEnvironment() {
    // Generate clouds
    this.clouds = [
      { x: 30, y: 70, width: 90, speed: 12, scale: 1, opacity: 0.85 },
      { x: 180, y: 130, width: 75, speed: 8, scale: 0.8, opacity: 0.75 },
      { x: 290, y: 50, width: 110, speed: 14, scale: 1.1, opacity: 0.9 },
    ];

    // Generate hills
    this.hills = [
      { x: 30, y: this.groundY, radius: 55, color: '#6bc272' },
      { x: 130, y: this.groundY, radius: 75, color: '#6bc272' },
      { x: 240, y: this.groundY, radius: 60, color: '#6bc272' },
      { x: 340, y: this.groundY, radius: 80, color: '#6bc272' },
    ];

    // Generate stars for night theme
    this.stars = [];
    for (let i = 0; i < 40; i++) {
      this.stars.push({
        x: Math.random() * DEFAULT_CONFIG.canvasWidth,
        y: Math.random() * (this.groundY - 100),
        brightness: 0.3 + Math.random() * 0.7,
        speed: 1 + Math.random() * 3,
      });
    }
  }

  public setSkin(skin: BirdSkin) {
    this.currentSkin = skin;
    StorageManager.setSkin(skin.id);
  }

  public setTheme(theme: SkyTheme) {
    this.currentTheme = theme;
    StorageManager.setTheme(theme);
  }

  public toggleSound(): boolean {
    const isMuted = soundManager.getMuted();
    const newMuted = !isMuted;
    soundManager.setMuted(newMuted);
    StorageManager.setSound(!newMuted);
    if (!newMuted) {
      soundManager.playClick();
    }
    return !newMuted;
  }

  public resetReadyState() {
    this.state = 'READY';
    this.score = 0;
    this.isNewRecord = false;
    this.currentMedal = null;
    this.flapsInCurrentGame = 0;
    this.pipesPassedInCurrentGame = 0;

    this.birdX = 90;
    this.birdY = 250;
    this.birdVy = 0;
    this.birdRotation = 0;
    this.wingFrame = 1;
    this.wingTimer = 0;

    this.pipes = [];
    this.nextPipeId = 1;
    this.lastPipeSpawnX = DEFAULT_CONFIG.canvasWidth + 60;

    this.screenShake = 0;
    this.hitFlash = 0;
    this.hitstopTimer = 0;
    this.birdDeadOnGround = false;
    this.particles.clear();

    const stats = StorageManager.getStats();
    this.bestScore = stats.highScore;

    this.onStateChange?.(this.state);
    this.onScoreChange?.(0);
  }

  public flap() {
    if (this.state === 'READY') {
      this.state = 'PLAYING';
      this.onStateChange?.(this.state);
      this.applyFlap();
      return;
    }

    if (this.state === 'PLAYING') {
      this.applyFlap();
    }
  }

  private applyFlap() {
    this.birdVy = DEFAULT_CONFIG.flapStrength;
    this.birdRotation = -0.42; // Snappy upward tilt (~ -24 deg)
    this.wingFrame = 0;
    this.wingTimer = 0;
    this.flapsInCurrentGame++;

    // Audio & particles
    soundManager.playFlap();
    this.particles.emitFlapFeathers(this.birdX, this.birdY, this.currentSkin.featherColor);
  }

  public pause() {
    if (this.state === 'PLAYING') {
      this.state = 'PAUSED';
      soundManager.playClick();
      this.onStateChange?.(this.state);
    }
  }

  public resume() {
    if (this.state === 'PAUSED') {
      this.state = 'PLAYING';
      soundManager.playClick();
      this.lastTime = performance.now();
      this.onStateChange?.(this.state);
    }
  }

  private triggerGameOver() {
    if (this.state === 'GAME_OVER') return;

    this.state = 'GAME_OVER';
    soundManager.playHit();

    // Trigger hitstop and screen shake
    this.hitstopTimer = 0.05; // 50ms freeze frame
    this.screenShake = 14;
    this.hitFlash = 0.85;

    // Save statistics & check record
    const result = StorageManager.recordGame(
      this.score,
      this.flapsInCurrentGame,
      this.pipesPassedInCurrentGame
    );
    this.isNewRecord = result.isNewRecord;
    this.bestScore = result.stats.highScore;

    // Calculate medal earned
    if (this.score >= 40) {
      this.currentMedal = 'platinum';
    } else if (this.score >= 30) {
      this.currentMedal = 'gold';
    } else if (this.score >= 20) {
      this.currentMedal = 'silver';
    } else if (this.score >= 10) {
      this.currentMedal = 'bronze';
    } else {
      this.currentMedal = null;
    }

    if (this.currentMedal || this.isNewRecord) {
      setTimeout(() => soundManager.playMedalFanfare(), 350);
    } else {
      setTimeout(() => soundManager.playDie(), 180);
    }

    this.onStateChange?.(this.state);
    this.onGameOver?.({
      score: this.score,
      bestScore: this.bestScore,
      isNewRecord: this.isNewRecord,
      medal: this.currentMedal,
    });
  }

  public start() {
    this.isDestroyed = false;
    this.lastTime = performance.now();
    const loop = (currentTime: number) => {
      if (this.isDestroyed) return;

      const rawDt = (currentTime - this.lastTime) / 1000;
      this.lastTime = currentTime;
      // Clamp delta time to avoid huge tunneling jumps when browser lags or tab switches
      const dt = Math.min(rawDt, 0.05);

      this.update(dt, currentTime / 1000);
      this.render(currentTime / 1000);

      this.animFrameId = requestAnimationFrame(loop);
    };

    this.animFrameId = requestAnimationFrame(loop);
  }

  public destroy() {
    this.isDestroyed = true;
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
  }

  private update(dt: number, totalTime: number) {
    // Hitstop delay
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      return;
    }

    // Screen shake decay
    if (this.screenShake > 0) {
      this.screenShake = Math.max(0, this.screenShake - dt * 45);
    }

    // Flash decay
    if (this.hitFlash > 0) {
      this.hitFlash = Math.max(0, this.hitFlash - dt * 5);
    }

    // Always update particles
    this.particles.update(dt);

    // Update parallax clouds
    for (const c of this.clouds) {
      c.x -= c.speed * dt;
      if (c.x + c.width < 0) {
        c.x = DEFAULT_CONFIG.canvasWidth + 20 + Math.random() * 40;
        c.y = 40 + Math.random() * 100;
      }
    }

    // 1. READY STATE
    if (this.state === 'READY') {
      // Gentle floating sine wave bobbing
      this.birdY = 250 + Math.sin(totalTime * 4.2) * 7;
      this.birdRotation = Math.sin(totalTime * 4.2) * 0.06;

      // Gentle wing flapping
      this.wingTimer += dt;
      if (this.wingTimer > 0.12) {
        this.wingTimer = 0;
        this.wingFrame = (this.wingFrame + 1) % 3;
      }

      // Idle ground scroll
      this.groundScroll += 40 * dt;
      return;
    }

    // 2. PAUSED STATE
    if (this.state === 'PAUSED') {
      return;
    }

    // 3. PLAYING STATE
    if (this.state === 'PLAYING') {
      const difficulty = PhysicsEngine.getDifficulty(this.score);

      // Scroll ground
      this.groundScroll += difficulty.speed * dt;

      // Apply bird gravity & velocity
      this.birdVy = Math.min(DEFAULT_CONFIG.maxFallSpeed, this.birdVy + DEFAULT_CONFIG.gravity * dt);
      this.birdY += this.birdVy * dt;

      // Realistic angle rotation based on velocity
      if (this.birdVy < 0) {
        // Angled upward
        this.birdRotation = Math.max(-0.45, this.birdRotation - dt * 5);
      } else {
        // Nosediving downward
        this.birdRotation = Math.min(1.4, this.birdRotation + dt * 3.8);
      }

      // Wing animation (flaps quickly when climbing, holds glide frame when falling)
      this.wingTimer += dt;
      const wingInterval = this.birdVy < 0 ? 0.07 : 0.16;
      if (this.wingTimer > wingInterval) {
        this.wingTimer = 0;
        this.wingFrame = (this.wingFrame + 1) % 3;
      }

      // Pipe movement & generation
      for (let i = this.pipes.length - 1; i >= 0; i--) {
        const pipe = this.pipes[i];
        pipe.x -= difficulty.speed * dt;

        // Check scoring: bird passed the pipe pair
        if (!pipe.scored && this.birdX > pipe.x + pipe.width) {
          pipe.scored = true;
          this.score++;
          this.pipesPassedInCurrentGame++;
          soundManager.playScore();
          this.particles.emitScoreSparkles(pipe.x + pipe.width / 2, (pipe.topHeight + pipe.bottomY) / 2);
          this.onScoreChange?.(this.score);
        }

        // Remove off-screen pipes
        if (pipe.x + pipe.width < -30) {
          this.pipes.splice(i, 1);
        }
      }

      // Spawn new pipe pair if needed
      const lastPipe = this.pipes[this.pipes.length - 1];
      const shouldSpawn =
        !lastPipe ||
        DEFAULT_CONFIG.canvasWidth - lastPipe.x >= DEFAULT_CONFIG.pipeSpawnDistance;

      if (shouldSpawn) {
        const gap = difficulty.gap;
        const minTop = 60;
        const maxTop = this.groundY - gap - 60;
        const topHeight = minTop + Math.random() * (maxTop - minTop);

        this.pipes.push({
          id: this.nextPipeId++,
          x: DEFAULT_CONFIG.canvasWidth + 20,
          topHeight: Math.floor(topHeight),
          bottomY: Math.floor(topHeight + gap),
          gap,
          width: 58,
          scored: false,
        });
      }

      // Collision Detection
      const hasCollided = PhysicsEngine.checkCollision(
        this.birdX,
        this.birdY,
        this.pipes,
        this.groundY
      );

      if (hasCollided) {
        this.triggerGameOver();
      }
      return;
    }

    // 4. GAME OVER STATE
    if (this.state === 'GAME_OVER') {
      if (!this.birdDeadOnGround) {
        // Fall swiftly to the ground
        this.birdVy = Math.min(DEFAULT_CONFIG.maxFallSpeed, this.birdVy + DEFAULT_CONFIG.gravity * dt);
        this.birdY += this.birdVy * dt;
        this.birdRotation = Math.min(1.55, this.birdRotation + dt * 6);

        // Ground hit
        if (this.birdY + 10 >= this.groundY) {
          this.birdY = this.groundY - 10;
          this.birdDeadOnGround = true;
          this.birdVy = 0;
          this.particles.emitImpactDust(this.birdX, this.groundY);
          soundManager.playHit();
        }
      }
    }
  }

  private render(totalTime: number) {
    const { ctx, canvas } = this;
    const width = DEFAULT_CONFIG.canvasWidth;
    const height = DEFAULT_CONFIG.canvasHeight;

    ctx.save();

    // Apply Screen Shake if active
    if (this.screenShake > 0) {
      const shakeX = (Math.random() - 0.5) * this.screenShake;
      const shakeY = (Math.random() - 0.5) * this.screenShake;
      ctx.translate(shakeX, shakeY);
    }

    // 1. Sky & Stars / Sun
    GameRenderer.drawSky(ctx, width, height, this.currentTheme, this.stars, totalTime);

    // 2. Clouds
    GameRenderer.drawClouds(ctx, this.clouds);

    // 3. Distant Hills
    GameRenderer.drawDistantHills(ctx, this.hills, this.groundY, this.currentTheme);

    // 4. Pipes
    for (const pipe of this.pipes) {
      GameRenderer.drawPipePair(ctx, pipe, height);
    }

    // 5. Particles (Behind ground, around bird and pipes)
    this.particles.render(ctx);

    // 6. Bird
    GameRenderer.drawBird(
      ctx,
      this.birdX,
      this.birdY,
      this.birdRotation,
      this.currentSkin,
      this.wingFrame
    );

    // 7. Ground (Visual floor with scrolling dirt & grass)
    GameRenderer.drawGround(ctx, width, this.groundY, DEFAULT_CONFIG.groundHeight, this.groundScroll);

    // 8. In-Game Active Score
    if (this.state === 'PLAYING') {
      GameRenderer.drawScore(ctx, this.score, width, 84);
    }

    // 9. White Flash on impact
    if (this.hitFlash > 0) {
      ctx.fillStyle = `rgba(255, 255, 255, ${this.hitFlash})`;
      ctx.fillRect(0, 0, width, height);
    }

    ctx.restore();
  }
}
