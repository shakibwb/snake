/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BirdSkin, BirdSkinId, GameStats, SkyTheme } from './types';

export const BIRD_SKINS: Record<BirdSkinId, BirdSkin> = {
  classic: {
    id: 'classic',
    name: 'Pip the Canary',
    bodyColor: '#ffd528',
    bodyHighlight: '#fff275',
    bodyShadow: '#e69819',
    wingColor: '#fff9b0',
    wingShadow: '#e6b800',
    bellyColor: '#ffffff',
    beakColor: '#f75c2f',
    beakShadow: '#d83610',
    featherColor: '#ffe566',
    unlockScore: 0,
  },
  ruby: {
    id: 'ruby',
    name: 'Ruby Cardinal',
    bodyColor: '#e63946',
    bodyHighlight: '#ff6b6b',
    bodyShadow: '#a81824',
    wingColor: '#ff858d',
    wingShadow: '#c9182b',
    bellyColor: '#f8d7da',
    beakColor: '#fca311',
    beakShadow: '#d47b00',
    featherColor: '#ff4d6d',
    unlockScore: 10,
  },
  cyber: {
    id: 'cyber',
    name: 'Byte Hawk',
    bodyColor: '#00f0ff',
    bodyHighlight: '#a0fcff',
    bodyShadow: '#009bb3',
    wingColor: '#ff007f',
    wingShadow: '#b30059',
    bellyColor: '#e0ffff',
    beakColor: '#ffe600',
    beakShadow: '#b8a500',
    featherColor: '#00f0ff',
    unlockScore: 20,
  },
  phoenix: {
    id: 'phoenix',
    name: 'Solar Phoenix',
    bodyColor: '#ff9f1c',
    bodyHighlight: '#ffd166',
    bodyShadow: '#c46800',
    wingColor: '#ff4040',
    wingShadow: '#b81414',
    bellyColor: '#ffe8a3',
    beakColor: '#ffe600',
    beakShadow: '#cc9900',
    featherColor: '#ffaa00',
    unlockScore: 30,
  },
  shadow: {
    id: 'shadow',
    name: 'Eclipse Raven',
    bodyColor: '#2b2d42',
    bodyHighlight: '#4a4e69',
    bodyShadow: '#141521',
    wingColor: '#8338ec',
    wingShadow: '#521f9c',
    bellyColor: '#9a8c98',
    beakColor: '#ff0055',
    beakShadow: '#aa0038',
    featherColor: '#8338ec',
    unlockScore: 40,
  },
};

const STORAGE_KEY = 'flappy_pixel_flight_stats_v1';

const defaultStats: GameStats = {
  highScore: 0,
  gamesPlayed: 0,
  totalPipesPassed: 0,
  totalFlaps: 0,
  unlockedSkins: ['classic'],
  soundEnabled: true,
  selectedSkin: 'classic',
  selectedTheme: 'day',
};

export class StorageManager {
  private static cachedStats: GameStats | null = null;

  public static getStats(): GameStats {
    if (this.cachedStats) return this.cachedStats;
    if (typeof window === 'undefined') return defaultStats;

    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        this.cachedStats = {
          ...defaultStats,
          ...parsed,
          unlockedSkins: parsed.unlockedSkins || ['classic'],
        };
        return this.cachedStats!;
      }
    } catch {
      // Fallback
    }

    this.cachedStats = { ...defaultStats };
    return this.cachedStats;
  }

  public static saveStats(stats: Partial<GameStats>): GameStats {
    const current = this.getStats();
    const updated: GameStats = {
      ...current,
      ...stats,
    };

    // Check newly unlocked skins based on high score
    Object.values(BIRD_SKINS).forEach((skin) => {
      if (updated.highScore >= skin.unlockScore && !updated.unlockedSkins.includes(skin.id)) {
        updated.unlockedSkins.push(skin.id);
      }
    });

    this.cachedStats = updated;
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // Fallback
      }
    }
    return updated;
  }

  public static recordGame(score: number, flapsInGame: number, pipesInGame: number): { isNewRecord: boolean; stats: GameStats } {
    const stats = this.getStats();
    const isNewRecord = score > stats.highScore;
    const newHighScore = Math.max(stats.highScore, score);

    const updated = this.saveStats({
      highScore: newHighScore,
      gamesPlayed: stats.gamesPlayed + 1,
      totalPipesPassed: stats.totalPipesPassed + pipesInGame,
      totalFlaps: stats.totalFlaps + flapsInGame,
    });

    return { isNewRecord, stats: updated };
  }

  public static setSkin(skinId: BirdSkinId): GameStats {
    return this.saveStats({ selectedSkin: skinId });
  }

  public static setTheme(theme: SkyTheme): GameStats {
    return this.saveStats({ selectedTheme: theme });
  }

  public static setSound(enabled: boolean): GameStats {
    return this.saveStats({ soundEnabled: enabled });
  }
}
