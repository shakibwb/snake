/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Volume2, VolumeX, Pause, Sun, Moon, Sunset, Trophy, BarChart2 } from 'lucide-react';
import { GameState, SkyTheme } from '../game/types';

interface HUDProps {
  gameState: GameState;
  score: number;
  bestScore: number;
  isMuted: boolean;
  currentTheme: SkyTheme;
  onToggleSound: () => void;
  onToggleTheme: () => void;
  onPause: () => void;
  onOpenStats: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  gameState,
  bestScore,
  isMuted,
  currentTheme,
  onToggleSound,
  onToggleTheme,
  onPause,
  onOpenStats,
}) => {
  return (
    <div className="absolute inset-x-0 top-0 p-3 pointer-events-none z-20 flex items-center justify-between">
      {/* Left zone: Pause during play, or trophy best score */}
      <div className="flex items-center gap-2 pointer-events-auto">
        {gameState === 'PLAYING' ? (
          <button
            onClick={onPause}
            aria-label="Pause Game"
            className="w-10 h-10 rounded-lg bg-black/60 hover:bg-black/80 active:translate-y-0.5 border-2 border-white/20 text-white flex items-center justify-center transition-transform shadow-md cursor-pointer"
          >
            <Pause size={18} className="fill-white" />
          </button>
        ) : (
          <button
            onClick={onOpenStats}
            aria-label="Open Statistics"
            className="px-3 h-10 rounded-lg bg-black/60 hover:bg-black/80 active:translate-y-0.5 border-2 border-white/20 text-white flex items-center gap-1.5 transition-transform shadow-md cursor-pointer"
          >
            <Trophy size={16} className="text-amber-400" />
            <span className="font-arcade text-xs text-amber-300 tabular-nums">
              {bestScore}
            </span>
          </button>
        )}
      </div>

      {/* Right zone: Audio, Theme & Stats toggles */}
      <div className="flex items-center gap-2 pointer-events-auto">
        {gameState !== 'PLAYING' && (
          <button
            onClick={onOpenStats}
            aria-label="View Leaderboard & Stats"
            className="w-10 h-10 rounded-lg bg-black/60 hover:bg-black/80 active:translate-y-0.5 border-2 border-white/20 text-white flex items-center justify-center transition-transform shadow-md cursor-pointer"
          >
            <BarChart2 size={18} />
          </button>
        )}

        <button
          onClick={onToggleTheme}
          aria-label={`Current theme: ${currentTheme}. Click to switch.`}
          className="w-10 h-10 rounded-lg bg-black/60 hover:bg-black/80 active:translate-y-0.5 border-2 border-white/20 text-white flex items-center justify-center transition-transform shadow-md cursor-pointer"
        >
          {currentTheme === 'day' && <Sun size={18} className="text-amber-400" />}
          {currentTheme === 'sunset' && <Sunset size={18} className="text-orange-400" />}
          {currentTheme === 'night' && <Moon size={18} className="text-indigo-300" />}
        </button>

        <button
          onClick={onToggleSound}
          aria-label={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          className="w-10 h-10 rounded-lg bg-black/60 hover:bg-black/80 active:translate-y-0.5 border-2 border-white/20 text-white flex items-center justify-center transition-transform shadow-md cursor-pointer"
        >
          {isMuted ? (
            <VolumeX size={18} className="text-red-400" />
          ) : (
            <Volume2 size={18} className="text-emerald-400" />
          )}
        </button>
      </div>
    </div>
  );
};
