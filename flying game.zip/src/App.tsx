/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useCallback } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { HUD } from './components/HUD';
import { ReadyScreen } from './components/ReadyScreen';
import { PauseModal } from './components/PauseModal';
import { GameOverModal } from './components/GameOverModal';
import { StatsModal } from './components/StatsModal';
import { GameEngine } from './game/engine';
import { BIRD_SKINS, StorageManager } from './game/storage';
import { BirdSkin, GameState, MedalType, SkyTheme } from './game/types';
import { Maximize2, Minimize2 } from 'lucide-react';

export default function App() {
  const [engine, setEngine] = useState<GameEngine | null>(null);
  const [gameState, setGameState] = useState<GameState>('READY');
  const [score, setScore] = useState<number>(0);
  const [stats, setStats] = useState(() => StorageManager.getStats());
  const [currentSkin, setCurrentSkin] = useState<BirdSkin>(
    () => BIRD_SKINS[stats.selectedSkin] || BIRD_SKINS.classic
  );
  const [currentTheme, setCurrentTheme] = useState<SkyTheme>(stats.selectedTheme);
  const [isMuted, setIsMuted] = useState<boolean>(!stats.soundEnabled);
  const [isStatsOpen, setIsStatsOpen] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Game over state data
  const [gameOverData, setGameOverData] = useState<{
    score: number;
    bestScore: number;
    isNewRecord: boolean;
    medal: MedalType;
  }>({
    score: 0,
    bestScore: stats.highScore,
    isNewRecord: false,
    medal: null,
  });

  const handleEngineReady = useCallback((inst: GameEngine) => {
    setEngine(inst);
  }, []);

  const handleStateChange = useCallback((newState: GameState) => {
    setGameState(newState);
  }, []);

  const handleScoreChange = useCallback((newScore: number) => {
    setScore(newScore);
  }, []);

  const handleGameOver = useCallback(
    (data: { score: number; bestScore: number; isNewRecord: boolean; medal: MedalType }) => {
      setGameOverData(data);
      setStats(StorageManager.getStats());
    },
    []
  );

  const handleToggleSound = useCallback(() => {
    if (engine) {
      const soundOn = engine.toggleSound();
      setIsMuted(!soundOn);
      setStats(StorageManager.getStats());
    }
  }, [engine]);

  const handleToggleTheme = useCallback(() => {
    const themes: SkyTheme[] = ['day', 'sunset', 'night'];
    const nextIdx = (themes.indexOf(currentTheme) + 1) % themes.length;
    const nextTheme = themes[nextIdx];
    setCurrentTheme(nextTheme);
    if (engine) {
      engine.setTheme(nextTheme);
    }
    setStats(StorageManager.getStats());
  }, [currentTheme, engine]);

  const handleSelectSkin = useCallback(
    (skin: BirdSkin) => {
      // Allow equipping if unlocked
      if (stats.unlockedSkins.includes(skin.id)) {
        setCurrentSkin(skin);
        if (engine) {
          engine.setSkin(skin);
        }
        setStats(StorageManager.getStats());
      } else {
        // Just preview on ready screen
        setCurrentSkin(skin);
      }
    },
    [engine, stats.unlockedSkins]
  );

  const handleStartGame = useCallback(() => {
    if (engine) {
      engine.flap();
    }
  }, [engine]);

  const handlePause = useCallback(() => {
    if (engine) {
      engine.pause();
    }
  }, [engine]);

  const handleResume = useCallback(() => {
    if (engine) {
      engine.resume();
    }
  }, [engine]);

  const handleRestart = useCallback(() => {
    if (engine) {
      engine.resetReadyState();
      // Start immediately
      engine.flap();
    }
  }, [engine]);

  const handleHome = useCallback(() => {
    if (engine) {
      engine.resetReadyState();
    }
  }, [engine]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  return (
    <div className="relative w-screen h-screen bg-slate-950 flex items-center justify-center overflow-hidden font-sans select-none">
      {/* Background arcade cabinet styling for desktop viewports */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(30,41,59,0.5)_0%,rgba(2,6,23,0.95)_100%)] pointer-events-none" />

      {/* 9:16 Game Viewport Frame */}
      <div className="relative w-full max-w-[420px] h-full max-h-[780px] sm:h-[92vh] sm:rounded-2xl sm:border-4 sm:border-slate-800 sm:shadow-[0_0_50px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col justify-center bg-black">
        {/* Isolated Canvas Viewport */}
        <GameCanvas
          onEngineReady={handleEngineReady}
          onStateChange={handleStateChange}
          onScoreChange={handleScoreChange}
          onGameOver={handleGameOver}
          currentSkin={currentSkin}
          currentTheme={currentTheme}
        />

        {/* Low-Occlusion Top HUD */}
        <HUD
          gameState={gameState}
          score={score}
          bestScore={stats.highScore}
          isMuted={isMuted}
          currentTheme={currentTheme}
          onToggleSound={handleToggleSound}
          onToggleTheme={handleToggleTheme}
          onPause={handlePause}
          onOpenStats={() => setIsStatsOpen(true)}
        />

        {/* Ready / Start Overlay */}
        {gameState === 'READY' && (
          <ReadyScreen
            currentSkin={currentSkin}
            unlockedSkins={stats.unlockedSkins}
            highScore={stats.highScore}
            onSelectSkin={handleSelectSkin}
            onStartGame={handleStartGame}
          />
        )}

        {/* Pause Overlay */}
        {gameState === 'PAUSED' && (
          <PauseModal
            score={score}
            bestScore={stats.highScore}
            onResume={handleResume}
            onRestart={handleRestart}
            onHome={handleHome}
          />
        )}

        {/* Game Over Modal */}
        {gameState === 'GAME_OVER' && (
          <GameOverModal
            score={gameOverData.score}
            bestScore={gameOverData.bestScore}
            isNewRecord={gameOverData.isNewRecord}
            medal={gameOverData.medal}
            onRestart={handleRestart}
            onHome={handleHome}
            onOpenStats={() => setIsStatsOpen(true)}
          />
        )}

        {/* Lifetime Stats & Medal Cabinet Modal */}
        {isStatsOpen && (
          <StatsModal
            stats={stats}
            currentSkin={currentSkin}
            onSelectSkin={handleSelectSkin}
            onClose={() => setIsStatsOpen(false)}
          />
        )}
      </div>

      {/* Desktop Controls Hint Bar & Fullscreen Toggle */}
      <div className="hidden sm:flex absolute bottom-3 items-center gap-6 text-[11px] font-mono text-slate-500 pointer-events-auto">
        <span>Space / Click: Flap</span>
        <span>·</span>
        <span>Esc / P: Pause</span>
        <span>·</span>
        <button
          onClick={toggleFullscreen}
          className="flex items-center gap-1 hover:text-slate-300 transition-colors cursor-pointer"
        >
          {isFullscreen ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
          <span>{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</span>
        </button>
      </div>
    </div>
  );
}
