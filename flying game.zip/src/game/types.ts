/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type GameState = 'READY' | 'PLAYING' | 'PAUSED' | 'GAME_OVER';

export type SkyTheme = 'day' | 'sunset' | 'night';

export type BirdSkinId = 'classic' | 'ruby' | 'cyber' | 'phoenix' | 'shadow';

export interface BirdSkin {
  id: BirdSkinId;
  name: string;
  bodyColor: string;
  bodyHighlight: string;
  bodyShadow: string;
  wingColor: string;
  wingShadow: string;
  bellyColor: string;
  beakColor: string;
  beakShadow: string;
  featherColor: string;
  unlockScore: number;
}

export interface GameStats {
  highScore: number;
  gamesPlayed: number;
  totalPipesPassed: number;
  totalFlaps: number;
  unlockedSkins: BirdSkinId[];
  soundEnabled: boolean;
  selectedSkin: BirdSkinId;
  selectedTheme: SkyTheme;
}

export interface PipePair {
  id: number;
  x: number;
  topHeight: number;
  bottomY: number;
  gap: number;
  width: number;
  scored: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  rotation?: number;
  vRot?: number;
  shape?: 'square' | 'feather' | 'sparkle' | 'circle';
}

export interface Cloud {
  x: number;
  y: number;
  width: number;
  speed: number;
  scale: number;
  opacity: number;
}

export interface Hill {
  x: number;
  y: number;
  radius: number;
  color: string;
}

export type MedalType = 'bronze' | 'silver' | 'gold' | 'platinum' | null;

export interface GamePhysicsConfig {
  gravity: number;
  flapStrength: number;
  maxFallSpeed: number;
  pipeSpeed: number;
  pipeSpawnDistance: number;
  initialPipeGap: number;
  minPipeGap: number;
  canvasWidth: number;
  canvasHeight: number;
  groundHeight: number;
}
