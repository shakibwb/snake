/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Particle } from './types';

export class ParticleSystem {
  private particles: Particle[] = [];

  public emitFlapFeathers(x: number, y: number, color: string) {
    const count = 5 + Math.floor(Math.random() * 3);
    for (let i = 0; i < count; i++) {
      const angle = Math.PI * 0.5 + (Math.random() - 0.5) * 1.2;
      const speed = 40 + Math.random() * 80;
      this.particles.push({
        x: x - 12 + Math.random() * 6,
        y: y + 4 + Math.random() * 6,
        vx: -Math.cos(angle) * speed - 30,
        vy: Math.sin(angle) * speed * 0.4 + 20,
        size: 3 + Math.random() * 3,
        color,
        alpha: 1,
        life: 0,
        maxLife: 0.4 + Math.random() * 0.3,
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 8,
        shape: 'feather',
      });
    }
  }

  public emitScoreSparkles(x: number, y: number) {
    const colors = ['#ffe600', '#ffffff', '#a0fcff', '#ffbe0b'];
    for (let i = 0; i < 14; i++) {
      const angle = (i / 14) * Math.PI * 2 + Math.random() * 0.3;
      const speed = 70 + Math.random() * 110;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 2.5 + Math.random() * 3.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        life: 0,
        maxLife: 0.5 + Math.random() * 0.3,
        rotation: 0,
        vRot: (Math.random() - 0.5) * 10,
        shape: 'sparkle',
      });
    }
  }

  public emitImpactDust(x: number, y: number) {
    for (let i = 0; i < 16; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 30 + Math.random() * 90;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 20,
        size: 3 + Math.random() * 4,
        color: Math.random() > 0.5 ? '#d5c489' : '#ffffff',
        alpha: 1,
        life: 0,
        maxLife: 0.35 + Math.random() * 0.25,
        shape: 'square',
      });
    }
  }

  public update(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }

      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.alpha = 1 - p.life / p.maxLife;

      if (p.shape === 'feather') {
        p.vy += 80 * dt; // slight gravity on feathers
        p.vx *= 0.96;
        if (p.vRot) p.rotation = (p.rotation || 0) + p.vRot * dt;
      } else if (p.shape === 'sparkle') {
        p.vx *= 0.92;
        p.vy *= 0.92;
        if (p.vRot) p.rotation = (p.rotation || 0) + p.vRot * dt;
      } else {
        p.vx *= 0.9;
        p.vy += 60 * dt;
      }
    }
  }

  public render(ctx: CanvasRenderingContext2D) {
    ctx.save();
    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.fillStyle = p.color;

      if (p.shape === 'feather') {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation || 0);
        // Draw cute little pixel feather
        ctx.fillRect(-p.size, -p.size * 0.5, p.size * 2, p.size);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-p.size * 0.4, -1, p.size * 0.8, 2);
        ctx.restore();
      } else if (p.shape === 'sparkle') {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation || 0);
        const s = p.size;
        // Pixel cross sparkle
        ctx.fillRect(-s, -1, s * 2, 2);
        ctx.fillRect(-1, -s, 2, s * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-1, -1, 2, 2);
        ctx.restore();
      } else {
        // Pixel square dust
        ctx.fillRect(Math.floor(p.x - p.size / 2), Math.floor(p.y - p.size / 2), p.size, p.size);
      }
    }
    ctx.restore();
  }

  public clear() {
    this.particles = [];
  }
}
